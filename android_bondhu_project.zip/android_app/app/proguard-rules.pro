-keepclassmembers class com.bondhuai.app.MainActivity$BondhuNativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.bondhuai.app.BondhuApplication { *; }
-keep class com.onesignal.** { *; }

