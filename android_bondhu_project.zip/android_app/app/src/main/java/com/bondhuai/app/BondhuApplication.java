package com.bondhuai.app;

import android.app.Application;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import androidx.annotation.NonNull;
import com.onesignal.OneSignal;
import com.onesignal.debug.LogLevel;
import com.onesignal.notifications.INotificationClickEvent;
import com.onesignal.notifications.INotificationClickListener;
import com.onesignal.user.IUserStateObserver;
import com.onesignal.user.UserChangedState;
import com.onesignal.user.subscriptions.IPushSubscriptionObserver;
import com.onesignal.user.subscriptions.PushSubscriptionChangedState;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

public class BondhuApplication extends Application {
    public static final String ONESIGNAL_APP_ID = "4472573d-e89f-47d8-98a3-598151b49380";
    private static final String PREFS_NAME = "bondhu_native_prefs";
    private static final String KEY_ONESIGNAL_SUB_ID = "onesignal_sub_id";
    private static final String KEY_ONESIGNAL_EXT_ID = "onesignal_external_id";
    private static final String KEY_ONESIGNAL_VERIFIED_EXT_ID = "onesignal_verified_external_id";
    private static final String KEY_ONESIGNAL_EMAIL = "onesignal_email";
    private static final String KEY_ONESIGNAL_DISPLAY_NAME = "onesignal_display_name";

    @Override
    public void onCreate() {
        super.onCreate();

        BondhuNotificationHelper.ensureChannels(this);

        OneSignal.getDebug().setLogLevel(LogLevel.WARN);
        OneSignal.initWithContext(this, ONESIGNAL_APP_ID);

        try {
            String initialSubId = OneSignal.getUser().getPushSubscription().getId();
            if (initialSubId != null && !initialSubId.trim().isEmpty()) {
                persistAndBroadcastSubId(initialSubId.trim());
            }
            String pendingExtId = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_ONESIGNAL_EXT_ID, "");
            String pendingEmail = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_ONESIGNAL_EMAIL, "");
            String pendingName = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_ONESIGNAL_DISPLAY_NAME, "");
            String sdkExtId = OneSignal.getUser().getExternalId();
            if (pendingExtId != null && !pendingExtId.trim().isEmpty()
                    && (sdkExtId == null || !pendingExtId.trim().equals(sdkExtId.trim()))) {
                OneSignal.login(pendingExtId.trim());
            } else if (sdkExtId != null && !sdkExtId.trim().isEmpty()) {
                persistAndBroadcastExternalId(sdkExtId.trim());
            }
            if (pendingEmail != null && !pendingEmail.trim().isEmpty()) {
                try {
                    OneSignal.getUser().addEmail(pendingEmail.trim());
                } catch (Exception ignored) {}
            }
            if (pendingExtId != null && !pendingExtId.trim().isEmpty()) {
                applyOneSignalTags(pendingExtId, pendingEmail, pendingName);
            }
        } catch (Exception ignored) {}

        OneSignal.getUser().getPushSubscription().addObserver(new IPushSubscriptionObserver() {
            @Override
            public void onPushSubscriptionChange(@NonNull PushSubscriptionChangedState state) {
                String nextId = state.getCurrent().getId();
                if (nextId != null && !nextId.trim().isEmpty()) {
                    persistAndBroadcastSubId(nextId.trim());
                }
                try {
                    SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                    String savedExt = prefs.getString(KEY_ONESIGNAL_EXT_ID, "");
                    String savedEmail = prefs.getString(KEY_ONESIGNAL_EMAIL, "");
                    String savedName = prefs.getString(KEY_ONESIGNAL_DISPLAY_NAME, "");
                    String currentSdkExt = OneSignal.getUser().getExternalId();
                    if (savedExt != null && !savedExt.trim().isEmpty()
                            && (currentSdkExt == null || !savedExt.trim().equals(currentSdkExt.trim()))) {
                        OneSignal.login(savedExt.trim());
                    }
                    if (savedEmail != null && !savedEmail.trim().isEmpty()) {
                        try {
                            OneSignal.getUser().addEmail(savedEmail.trim());
                        } catch (Exception ignored) {}
                    }
                    if (savedExt != null && !savedExt.trim().isEmpty()) {
                        applyOneSignalTags(savedExt, savedEmail, savedName);
                    }
                } catch (Exception ignored) {}
            }
        });

        OneSignal.getUser().addObserver(new IUserStateObserver() {
            @Override
            public void onUserStateChange(@NonNull UserChangedState state) {
                String verifiedExt = state.getCurrent().getExternalId();
                persistAndBroadcastExternalId(verifiedExt != null ? verifiedExt.trim() : "");
            }
        });

        OneSignal.getNotifications().addClickListener(new INotificationClickListener() {
            @Override
            public void onClick(@NonNull INotificationClickEvent event) {
                JSONObject data = event.getNotification().getAdditionalData();
                String targetUrl = resolveTargetUrl(data, event.getNotification().getLaunchURL());

                Intent intent = new Intent(BondhuApplication.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                if (targetUrl != null && !targetUrl.isEmpty()) {
                    intent.putExtra("bondhu_target_url", targetUrl);
                }
                startActivity(intent);
            }
        });
    }

    private void persistAndBroadcastSubId(String subId) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putString(KEY_ONESIGNAL_SUB_ID, subId).apply();
        MainActivity.onOneSignalSubIdUpdated(subId);
    }

    private void applyOneSignalTags(String userId, String email, String displayName) {
        try {
            Map<String, String> tags = new HashMap<>();
            if (userId != null && !userId.trim().isEmpty()) {
                tags.put("bondhu_id", userId.trim());
                tags.put("user_id", userId.trim());
            }
            if (email != null && !email.trim().isEmpty()) {
                tags.put("gmail", email.trim().toLowerCase());
            }
            if (displayName != null && !displayName.trim().isEmpty()) {
                tags.put("display_name", displayName.trim());
            }
            if (!tags.isEmpty()) {
                OneSignal.getUser().addTags(tags);
            }
        } catch (Exception ignored) {}
    }

    private void persistAndBroadcastExternalId(String extId) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        if (extId != null && !extId.isEmpty()) {
            prefs.edit().putString(KEY_ONESIGNAL_VERIFIED_EXT_ID, extId).apply();
        } else {
            prefs.edit().remove(KEY_ONESIGNAL_VERIFIED_EXT_ID).apply();
        }
        MainActivity.onOneSignalExternalIdUpdated(extId != null ? extId : "");
    }

    private String resolveTargetUrl(JSONObject data, String launchUrl) {
        if (launchUrl != null && !launchUrl.trim().isEmpty()) {
            return launchUrl.trim();
        }
        if (data == null) return "/";

        String directUrl = data.optString("url", "").trim();
        if (!directUrl.isEmpty()) return directUrl;

        String callId = data.optString("callId", "").trim();
        if (!callId.isEmpty()) {
            return "/?callId=" + Uri.encode(callId) + "&callAction=open";
        }
        String groupId = data.optString("groupId", "").trim();
        if (!groupId.isEmpty()) {
            return "/?groupId=" + Uri.encode(groupId);
        }
        String chatWith = data.optString("chatWith", "").trim();
        if (chatWith.isEmpty()) {
            chatWith = data.optString("senderId", "").trim();
        }
        if (!chatWith.isEmpty()) {
            return "/?chatWith=" + Uri.encode(chatWith);
        }
        return "/";
    }
}
