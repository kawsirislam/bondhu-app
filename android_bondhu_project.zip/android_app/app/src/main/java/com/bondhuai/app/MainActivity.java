package com.bondhuai.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.firebase.messaging.FirebaseMessaging;
import com.onesignal.OneSignal;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    public static final String BASE_URL = "https://kowsar-ai.ai.studio";
    private static final String PREFS_NAME = "bondhu_native_prefs";
    private static final String KEY_FCM_TOKEN = "fcm_token";
    private static final String KEY_ONESIGNAL_SUB_ID = "onesignal_sub_id";
    private static final String KEY_ONESIGNAL_EXT_ID = "onesignal_external_id";
    private static final String KEY_ONESIGNAL_VERIFIED_EXT_ID = "onesignal_verified_external_id";
    private static final String KEY_ONESIGNAL_EMAIL = "onesignal_email";
    private static final String KEY_ONESIGNAL_DISPLAY_NAME = "onesignal_display_name";
    private static final String KEY_NOTIF_ASKED = "notif_asked";
    private static final int REQ_NOTIF_PERM = 1002;
    private static final int REQ_MEDIA_PERMS = 1003;

    private static WeakReference<MainActivity> activeInstance = new WeakReference<>(null);
    private static volatile boolean isForeground = false;

    private WebView webView;
    private String currentFcmToken = null;
    private String currentOneSignalSubId = null;
    private String pendingDeepLinkPath = null;
    private long lastOneSignalLoginAttemptMs = 0L;
    private String lastOneSignalLoginAttemptId = "";
    private ValueCallback<Uri[]> fileUploadCallback = null;
    private ActivityResultLauncher<Intent> filePickerLauncher;

    public static boolean isAppInForeground() {
        return isForeground;
    }

    public static void onTokenRefreshedFromService(String token) {
        if (token == null || token.trim().isEmpty()) return;
        MainActivity activity = activeInstance.get();
        if (activity != null && !activity.isFinishing()) {
            activity.runOnUiThread(() -> activity.saveAndInjectFcmToken(token.trim()));
        }
    }

    public static void onOneSignalSubIdUpdated(String subId) {
        if (subId == null || subId.trim().isEmpty()) return;
        MainActivity activity = activeInstance.get();
        if (activity != null && !activity.isFinishing()) {
            activity.runOnUiThread(() -> activity.saveAndInjectOneSignalSubId(subId.trim()));
        }
    }

    public static void onOneSignalExternalIdUpdated(String extId) {
        MainActivity activity = activeInstance.get();
        if (activity != null && !activity.isFinishing()) {
            activity.runOnUiThread(() -> activity.injectOneSignalExternalIdToWebView(extId != null ? extId.trim() : ""));
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        activeInstance = new WeakReference<>(this);

        BondhuNotificationHelper.ensureChannels(this);
        currentFcmToken = getSavedFcmToken();
        currentOneSignalSubId = resolveLiveOrSavedOneSignalSubId();
        pendingDeepLinkPath = extractTargetPathFromIntent(getIntent());

        filePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (fileUploadCallback == null) return;
                    Uri[] uris = WebChromeClient.FileChooserParams.parseResult(result.getResultCode(), result.getData());
                    fileUploadCallback.onReceiveValue(uris);
                    fileUploadCallback = null;
                }
        );

        webView = findViewById(R.id.webview);
        setupWebView();
        requestInitialPermissions();
        fetchRealFcmToken();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView != null && webView.canGoBack()) {
                    webView.goBack();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        webView.loadUrl(buildLoadUrl(pendingDeepLinkPath));
        pendingDeepLinkPath = null;
    }

    @Override
    protected void onResume() {
        super.onResume();
        isForeground = true;
        activeInstance = new WeakReference<>(this);
        if (currentFcmToken != null && !currentFcmToken.isEmpty()) {
            injectFcmTokenToWebView(currentFcmToken);
        }
        String liveSubId = resolveLiveOrSavedOneSignalSubId();
        if (liveSubId != null && !liveSubId.isEmpty()) {
            saveAndInjectOneSignalSubId(liveSubId);
        }
        ensurePendingOneSignalExternalId();
    }

    @Override
    protected void onPause() {
        super.onPause();
        isForeground = false;
    }

    @Override
    protected void onDestroy() {
        if (activeInstance.get() == this) {
            activeInstance = new WeakReference<>(null);
        }
        super.onDestroy();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String targetPath = extractTargetPathFromIntent(intent);
        if (targetPath != null && !targetPath.isEmpty() && webView != null) {
            webView.loadUrl(buildLoadUrl(targetPath));
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new BondhuNativeBridge(), "BondhuNative");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri == null) return false;
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    String host = uri.getHost() != null ? uri.getHost() : "";
                    if (host.equalsIgnoreCase("kowsar-ai.ai.studio") || host.endsWith(".ai.studio") || host.endsWith(".run.app") || host.contains("accounts.google.com") || host.contains("firebaseapp.com")) {
                        return false;
                    }
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                        return true;
                    } catch (Exception ignored) {
                        return false;
                    }
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (currentFcmToken != null && !currentFcmToken.isEmpty()) {
                    injectFcmTokenToWebView(currentFcmToken);
                }
                String liveSubId = resolveLiveOrSavedOneSignalSubId();
                if (liveSubId != null && !liveSubId.isEmpty()) {
                    saveAndInjectOneSignalSubId(liveSubId);
                }
                ensurePendingOneSignalExternalId();
                dispatchPermissionEventToWebView(getNotificationPermissionString());
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    ensureCameraAndMicPermissions();
                    request.grant(request.getResources());
                });
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (fileUploadCallback != null) {
                    fileUploadCallback.onReceiveValue(null);
                }
                fileUploadCallback = filePathCallback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    filePickerLauncher.launch(intent);
                    return true;
                } catch (Exception e) {
                    fileUploadCallback = null;
                    return false;
                }
            }
        });
    }

    private void fetchRealFcmToken() {
        try {
            FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
                if (!task.isSuccessful()) return;
                String token = task.getResult();
                if (token != null && !token.trim().isEmpty()) {
                    runOnUiThread(() -> saveAndInjectFcmToken(token.trim()));
                }
            });
        } catch (Exception ignored) {}
    }

    private void saveAndInjectFcmToken(String token) {
        currentFcmToken = token;
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putString(KEY_FCM_TOKEN, token).apply();
        injectFcmTokenToWebView(token);
    }

    private String getSavedFcmToken() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getString(KEY_FCM_TOKEN, null);
    }

    private void injectFcmTokenToWebView(String token) {
        if (webView == null || token == null || token.isEmpty()) return;
        String safeToken = token.replace("\\", "\\\\").replace("'", "\\'");
        String js = "try{"
                + "localStorage.setItem('bondhu_native_fcm_token','" + safeToken + "');"
                + "if(window.__BONDHU_SET_FCM_TOKEN__){window.__BONDHU_SET_FCM_TOKEN__('" + safeToken + "');}"
                + "window.dispatchEvent(new CustomEvent('bondhu:fcm-token',{detail:'" + safeToken + "'}));"
                + "}catch(e){}";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private String resolveLiveOrSavedOneSignalSubId() {
        try {
            String live = OneSignal.getUser().getPushSubscription().getId();
            if (live != null && !live.trim().isEmpty()) {
                return live.trim();
            }
        } catch (Exception ignored) {}
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        return prefs.getString(KEY_ONESIGNAL_SUB_ID, null);
    }

    private void saveAndInjectOneSignalSubId(String subId) {
        if (subId == null || subId.trim().isEmpty()) return;
        String clean = subId.trim();
        currentOneSignalSubId = clean;
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        prefs.edit().putString(KEY_ONESIGNAL_SUB_ID, clean).apply();
        injectOneSignalSubIdToWebView(clean);
    }

    private void injectOneSignalSubIdToWebView(String subId) {
        if (webView == null || subId == null || subId.isEmpty()) return;
        String safeId = subId.replace("\\", "\\\\").replace("'", "\\'");
        String js = "try{"
                + "localStorage.setItem('bondhu_onesignal_sub_id','" + safeId + "');"
                + "if(window.__BONDHU_SET_ONESIGNAL_ID__){window.__BONDHU_SET_ONESIGNAL_ID__('" + safeId + "');}"
                + "window.dispatchEvent(new CustomEvent('bondhu:onesignal-id',{detail:'" + safeId + "'}));"
                + "}catch(e){}";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void injectOneSignalExternalIdToWebView(String extId) {
        if (webView == null) return;
        String clean = extId != null ? extId.trim() : "";
        String safeId = clean.replace("\\", "\\\\").replace("'", "\\'");
        String js = "try{"
                + (clean.isEmpty()
                    ? "localStorage.removeItem('bondhu_onesignal_external_id');"
                    : "localStorage.setItem('bondhu_onesignal_external_id','" + safeId + "');")
                + "if(window.__BONDHU_SET_ONESIGNAL_EXTERNAL_ID__){window.__BONDHU_SET_ONESIGNAL_EXTERNAL_ID__('" + safeId + "');}"
                + "window.dispatchEvent(new CustomEvent('bondhu:onesignal-external-id',{detail:'" + safeId + "'}));"
                + "}catch(e){}";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void applyOneSignalTags(String userId, String email, String displayName) {
        try {
            Map<String, String> tags = new HashMap<>();
            if (userId != null && !userId.trim().isEmpty()) {
                tags.put("bondhu_id", userId.trim());
                tags.put("user_id", userId.trim());
            }
            if (email != null && !email.trim().isEmpty()) {
                tags.put("gmail", email.trim().toLowerCase());
            }
            if (displayName != null && !displayName.trim().isEmpty()) {
                tags.put("display_name", displayName.trim());
            }
            if (!tags.isEmpty()) {
                OneSignal.getUser().addTags(tags);
            }
        } catch (Exception ignored) {}
    }

    private void triggerOneSignalLoginThrottled(String userId) {
        if (userId == null || userId.trim().isEmpty()) return;
        String clean = userId.trim();
        long now = System.currentTimeMillis();
        if (clean.equals(lastOneSignalLoginAttemptId) && (now - lastOneSignalLoginAttemptMs) < 3500L) {
            return;
        }
        lastOneSignalLoginAttemptId = clean;
        lastOneSignalLoginAttemptMs = now;
        OneSignal.login(clean);
    }

    private void ensurePendingOneSignalExternalId() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String savedExt = prefs.getString(KEY_ONESIGNAL_EXT_ID, "");
        String savedEmail = prefs.getString(KEY_ONESIGNAL_EMAIL, "");
        String savedName = prefs.getString(KEY_ONESIGNAL_DISPLAY_NAME, "");
        try {
            String sdkExt = OneSignal.getUser().getExternalId();
            if (savedExt != null && !savedExt.trim().isEmpty()) {
                if (sdkExt == null || !savedExt.trim().equals(sdkExt.trim())) {
                    triggerOneSignalLoginThrottled(savedExt.trim());
                } else {
                    prefs.edit().putString(KEY_ONESIGNAL_VERIFIED_EXT_ID, sdkExt.trim()).apply();
                    injectOneSignalExternalIdToWebView(sdkExt.trim());
                }
                if (savedEmail != null && !savedEmail.trim().isEmpty()) {
                    try {
                        OneSignal.getUser().addEmail(savedEmail.trim());
                    } catch (Exception ignored) {}
                }
                applyOneSignalTags(savedExt, savedEmail, savedName);
            } else if (sdkExt != null && !sdkExt.trim().isEmpty()) {
                injectOneSignalExternalIdToWebView(sdkExt.trim());
            }
        } catch (Exception ignored) {}
    }

    private void dispatchPermissionEventToWebView(String perm) {
        if (webView == null) return;
        String js = "try{window.dispatchEvent(new CustomEvent('bondhu:notification-permission',{detail:'" + perm + "'}));}catch(e){}";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private String getNotificationPermissionString() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            return "granted";
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            return "granted";
        }
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean asked = prefs.getBoolean(KEY_NOTIF_ASKED, false);
        if (asked && !ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.POST_NOTIFICATIONS)) {
            return "denied";
        }
        return "default";
    }

    private void requestInitialPermissions() {
        List<String> needed = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putBoolean(KEY_NOTIF_ASKED, true).apply();
                needed.add(Manifest.permission.POST_NOTIFICATIONS);
            }
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.CAMERA);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO);
        }
        if (!needed.isEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toArray(new String[0]), REQ_MEDIA_PERMS);
        }
    }

    private void ensureCameraAndMicPermissions() {
        List<String> needed = new ArrayList<>();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.CAMERA);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO);
        }
        if (!needed.isEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toArray(new String[0]), REQ_MEDIA_PERMS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIF_PERM || requestCode == REQ_MEDIA_PERMS) {
            String perm = getNotificationPermissionString();
            dispatchPermissionEventToWebView(perm);
            if ("granted".equals(perm)) {
                try {
                    OneSignal.getUser().getPushSubscription().optIn();
                } catch (Exception ignored) {}
                if (currentFcmToken != null) {
                    injectFcmTokenToWebView(currentFcmToken);
                }
                String liveSubId = resolveLiveOrSavedOneSignalSubId();
                if (liveSubId != null && !liveSubId.isEmpty()) {
                    saveAndInjectOneSignalSubId(liveSubId);
                }
                ensurePendingOneSignalExternalId();
            }
        }
    }

    private String extractTargetPathFromIntent(Intent intent) {
        if (intent == null) return null;
        String directUrl = intent.getStringExtra("bondhu_target_url");
        if (directUrl != null && !directUrl.isEmpty()) return directUrl;

        Bundle extras = intent.getExtras();
        if (extras == null) return null;
        String urlExtra = extras.getString("url");
        if (urlExtra != null && !urlExtra.isEmpty()) return urlExtra;

        String callId = extras.getString("callId");
        if (callId != null && !callId.isEmpty()) {
            return "/?callId=" + Uri.encode(callId) + "&callAction=open";
        }
        String groupId = extras.getString("groupId");
        if (groupId != null && !groupId.isEmpty()) {
            return "/?groupId=" + Uri.encode(groupId);
        }
        String chatWith = extras.getString("chatWith");
        if (chatWith == null || chatWith.isEmpty()) {
            chatWith = extras.getString("senderId");
        }
        if (chatWith != null && !chatWith.isEmpty()) {
            return "/?chatWith=" + Uri.encode(chatWith);
        }
        return null;
    }

    private String buildLoadUrl(String path) {
        if (path == null || path.isEmpty()) return BASE_URL;
        if (path.startsWith("http://") || path.startsWith("https://")) return path;
        if (path.startsWith("/")) return BASE_URL + path;
        return BASE_URL + "/" + path;
    }

    public class BondhuNativeBridge {
        @JavascriptInterface
        public String getFcmToken() {
            return currentFcmToken != null ? currentFcmToken : "";
        }

        @JavascriptInterface
        public String getNotificationPermission() {
            return getNotificationPermissionString();
        }

        @JavascriptInterface
        public boolean isNotificationPermissionGranted() {
            return "granted".equals(getNotificationPermissionString());
        }

        @JavascriptInterface
        public String requestNotificationPermission() {
            String current = getNotificationPermissionString();
            if ("granted".equals(current)) {
                try {
                    OneSignal.getUser().getPushSubscription().optIn();
                } catch (Exception ignored) {}
                return "granted";
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().putBoolean(KEY_NOTIF_ASKED, true).apply();
                runOnUiThread(() -> ActivityCompat.requestPermissions(
                        MainActivity.this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        REQ_NOTIF_PERM
                ));
            }
            return current;
        }

        @JavascriptInterface
        public boolean isOneSignalSupported() {
            return true;
        }

        @JavascriptInterface
        public String getOneSignalId() {
            String id = resolveLiveOrSavedOneSignalSubId();
            return id != null ? id : "";
        }

        @JavascriptInterface
        public String getOneSignalSubscriptionId() {
            return getOneSignalId();
        }

        @JavascriptInterface
        public String getOneSignalExternalId() {
            try {
                String ext = OneSignal.getUser().getExternalId();
                if (ext != null && !ext.trim().isEmpty()) return ext.trim();
            } catch (Exception ignored) {}
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            String verified = prefs.getString(KEY_ONESIGNAL_VERIFIED_EXT_ID, "");
            return verified != null ? verified.trim() : "";
        }

        @JavascriptInterface
        public String getOneSignalEmail() {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            String email = prefs.getString(KEY_ONESIGNAL_EMAIL, "");
            return email != null ? email.trim() : "";
        }

        private String sanitizeJsonValue(String val) {
            if (val == null) return "";
            return val.trim().replace("\\", "").replace("\"", "");
        }

        @JavascriptInterface
        public String getOneSignalDiagnosticsJson() {
            String subId = resolveLiveOrSavedOneSignalSubId();
            String sdkExtId = "";
            try {
                String sdkExt = OneSignal.getUser().getExternalId();
                if (sdkExt != null) sdkExtId = sdkExt.trim();
            } catch (Exception ignored) {}
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            String savedExt = prefs.getString(KEY_ONESIGNAL_EXT_ID, "");
            String verifiedExt = !sdkExtId.isEmpty() ? sdkExtId : prefs.getString(KEY_ONESIGNAL_VERIFIED_EXT_ID, "");
            String savedEmail = prefs.getString(KEY_ONESIGNAL_EMAIL, "");
            String savedName = prefs.getString(KEY_ONESIGNAL_DISPLAY_NAME, "");
            String perm = getNotificationPermissionString();
            String safeSub = sanitizeJsonValue(subId);
            String safeSdkExt = sanitizeJsonValue(sdkExtId);
            String safeSavedExt = sanitizeJsonValue(savedExt);
            String safeVerifiedExt = sanitizeJsonValue(verifiedExt);
            String safeEmail = sanitizeJsonValue(savedEmail);
            String safeName = sanitizeJsonValue(savedName);
            return "{\"supported\":true,\"subscriptionId\":\"" + safeSub
                    + "\",\"externalId\":\"" + safeSdkExt
                    + "\",\"savedExternalId\":\"" + safeSavedExt
                    + "\",\"verifiedExternalId\":\"" + safeVerifiedExt
                    + "\",\"email\":\"" + safeEmail
                    + "\",\"displayName\":\"" + safeName
                    + "\",\"permission\":\"" + perm + "\"}";
        }

        private void verifyAndRetryOneSignalLogin(final String cleanId, final SharedPreferences prefs) {
            try {
                String currentSaved = prefs.getString(KEY_ONESIGNAL_EXT_ID, "");
                if (!cleanId.equals(currentSaved)) return; // Account already changed or logged out
                String sdkExtAfter = OneSignal.getUser().getExternalId();
                if (sdkExtAfter != null && cleanId.equals(sdkExtAfter.trim())) {
                    prefs.edit().putString(KEY_ONESIGNAL_VERIFIED_EXT_ID, cleanId).apply();
                    injectOneSignalExternalIdToWebView(cleanId);
                } else {
                    triggerOneSignalLoginThrottled(cleanId);
                }
                String savedEmail = prefs.getString(KEY_ONESIGNAL_EMAIL, "");
                String savedName = prefs.getString(KEY_ONESIGNAL_DISPLAY_NAME, "");
                if (savedEmail != null && !savedEmail.trim().isEmpty()) {
                    try {
                        OneSignal.getUser().addEmail(savedEmail.trim());
                    } catch (Exception ignored) {}
                }
                applyOneSignalTags(cleanId, savedEmail, savedName);
                String refreshedSubId = resolveLiveOrSavedOneSignalSubId();
                if (refreshedSubId != null && !refreshedSubId.isEmpty()) {
                    saveAndInjectOneSignalSubId(refreshedSubId);
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void loginOneSignalWithProfile(String userId, String email, String displayName) {
            if (userId == null) return;
            String cleanId = userId.trim();
            String cleanEmail = email != null ? email.trim().toLowerCase() : "";
            String cleanName = displayName != null ? displayName.trim() : "";
            if (cleanId.isEmpty()) return;
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            String currentSdkExt = "";
            try {
                String sdkExt = OneSignal.getUser().getExternalId();
                if (sdkExt != null) currentSdkExt = sdkExt.trim();
            } catch (Exception ignored) {}

            try {
                SharedPreferences.Editor editor = prefs.edit().putString(KEY_ONESIGNAL_EXT_ID, cleanId);
                if (!cleanEmail.isEmpty()) {
                    editor.putString(KEY_ONESIGNAL_EMAIL, cleanEmail);
                } else {
                    editor.remove(KEY_ONESIGNAL_EMAIL);
                }
                if (!cleanName.isEmpty()) {
                    editor.putString(KEY_ONESIGNAL_DISPLAY_NAME, cleanName);
                } else {
                    editor.remove(KEY_ONESIGNAL_DISPLAY_NAME);
                }
                editor.apply();

                if (!cleanId.equals(currentSdkExt)) {
                    prefs.edit().remove(KEY_ONESIGNAL_VERIFIED_EXT_ID).apply();
                    // In OneSignal SDK v5, OneSignal.login(newId) switches external_id atomically without calling logout() first
                    lastOneSignalLoginAttemptId = cleanId;
                    lastOneSignalLoginAttemptMs = System.currentTimeMillis();
                    OneSignal.login(cleanId);
                } else {
                    prefs.edit().putString(KEY_ONESIGNAL_VERIFIED_EXT_ID, cleanId).apply();
                    runOnUiThread(() -> injectOneSignalExternalIdToWebView(cleanId));
                }

                if (!cleanEmail.isEmpty()) {
                    try {
                        OneSignal.getUser().addEmail(cleanEmail);
                    } catch (Exception ignored) {}
                }
                applyOneSignalTags(cleanId, cleanEmail, cleanName);

                if ("granted".equals(getNotificationPermissionString())) {
                    OneSignal.getUser().getPushSubscription().optIn();
                }
                String subId = resolveLiveOrSavedOneSignalSubId();
                if (subId != null && !subId.isEmpty()) {
                    runOnUiThread(() -> saveAndInjectOneSignalSubId(subId));
                }
                if (webView != null) {
                    webView.postDelayed(() -> verifyAndRetryOneSignalLogin(cleanId, prefs), 2500);
                    webView.postDelayed(() -> verifyAndRetryOneSignalLogin(cleanId, prefs), 6000);
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void loginOneSignal(String userId, String email) {
            loginOneSignalWithProfile(userId, email, "");
        }

        @JavascriptInterface
        public void loginOneSignal(String userId) {
            loginOneSignalWithProfile(userId, "", "");
        }

        @JavascriptInterface
        public void logoutOneSignal() {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit()
                    .remove(KEY_ONESIGNAL_EXT_ID)
                    .remove(KEY_ONESIGNAL_VERIFIED_EXT_ID)
                    .remove(KEY_ONESIGNAL_EMAIL)
                    .remove(KEY_ONESIGNAL_DISPLAY_NAME)
                    .apply();
            try {
                OneSignal.logout();
                runOnUiThread(() -> injectOneSignalExternalIdToWebView(""));
            } catch (Exception ignored) {}
        }
    }
}
