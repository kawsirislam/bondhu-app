package com.bondhu.ai.nativebridge

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

class BondhuNotificationListenerService : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: BondhuNotificationListenerService? = null
            private set

        private val sensitiveKeywords = listOf("otp", "verification code", "pin", "password", "cvv", "one time password")
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
    }

    override fun onListenerDisconnected() {
        instance = null
        super.onListenerDisconnected()
    }

    fun readSafeNotifications(confirmed: Boolean): JSONObject {
        if (!confirmed) {
            return JSONObject().apply {
                put("ok", false)
                put("errorCode", "CONFIRMATION_REQUIRED")
                put("message", "নোটিফিকেশন পড়তে ব্যবহারকারীর অনুমতি প্রয়োজন।")
            }
        }

        val list = activeNotifications ?: emptyArray<StatusBarNotification>()
        val arr = JSONArray()
        for (sbn in list.take(15)) {
            val extras = sbn.notification?.extras ?: continue
            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: ""
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim() ?: ""
            val combined = "$title $text".lowercase()

            val isSensitive = sensitiveKeywords.any { combined.contains(it) } ||
                (Regex("\\b\\d{4,8}\\b").containsMatchIn(text) && combined.contains("code"))

            arr.put(JSONObject().apply {
                put("packageName", sbn.packageName)
                put("title", title)
                put("text", if (isSensitive) "[সুরক্ষিত: গোপনীয় OTP/Security তথ্য গোপন রাখা হয়েছে]" else text)
                put("redacted", isSensitive)
            })
        }

        return JSONObject().apply {
            put("ok", true)
            put("message", "${arr.length()}টি সক্রিয় নোটিফিকেশন পাওয়া গেছে।")
            put("details", JSONObject().put("notifications", arr))
        }
    }
}
