package com.bondhu.ai.nativebridge

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.webkit.JavascriptInterface
import org.json.JSONObject

/**
 * Exposed to Android WebView via:
 * webView.addJavascriptInterface(BondhuWebViewBridge(this), "BondhuAndroidBridge")
 */
class BondhuWebViewBridge(private val activity: Activity) {

    private val permissionManager = BondhuPermissionManager(activity)
    private val intentExecutor = BondhuIntentExecutor(activity)

    @JavascriptInterface
    fun getCapabilitiesJson(): String {
        return JSONObject().apply {
            put("isAndroidApk", true)
            put("hasAccessibility", permissionManager.isAccessibilityEnabled())
            put("hasNotificationAccess", permissionManager.hasNotificationAccess())
            put("hasCallPermission", permissionManager.hasCallPermission())
            put("hasSmsPermission", permissionManager.hasSmsPermission())
            put("hasMicPermission", permissionManager.hasMicPermission())
            put("hasBackgroundService", BondhuForegroundVoiceService.isServiceRunning)
        }.toString()
    }

    @JavascriptInterface
    fun checkPermissionsJson(): String {
        val caps = JSONObject(getCapabilitiesJson())
        return JSONObject().apply {
            put("ok", true)
            put("message", "Android APK পারমিশন স্ট্যাটাস পাওয়া গেছে।")
            put("details", caps)
        }.toString()
    }

    @JavascriptInterface
    fun requestRuntimePermission(permissionKey: String): Boolean {
        return permissionManager.requestSinglePermission(permissionKey)
    }

    @JavascriptInterface
    fun openApp(appNameOrPackage: String): String {
        return intentExecutor.openApp(appNameOrPackage).toString()
    }

    @JavascriptInterface
    fun findInstalledApp(query: String): String {
        return intentExecutor.findInstalledApp(query).toString()
    }

    @JavascriptInterface
    fun makePhoneCall(contactOrNumber: String): String {
        return intentExecutor.makePhoneCall(contactOrNumber).toString()
    }

    @JavascriptInterface
    fun prepareOrSendSms(contactOrNumber: String, textBody: String, confirmed: Boolean): String {
        return intentExecutor.prepareOrSendSms(contactOrNumber, textBody, confirmed).toString()
    }

    @JavascriptInterface
    fun openNativeCamera(): String {
        return intentExecutor.openNativeCamera().toString()
    }

    @JavascriptInterface
    fun readActiveNotifications(confirmed: Boolean): String {
        val listener = BondhuNotificationListenerService.instance
            ?: return JSONObject().apply {
                put("ok", false)
                put("errorCode", "NOTIFICATION_SERVICE_DISABLED")
                put("message", "Notification Listener অনুমতি চালু করা নেই।")
            }.toString()
        return listener.readSafeNotifications(confirmed).toString()
    }

    @JavascriptInterface
    fun findDeviceFiles(query: String): String {
        return intentExecutor.findDeviceFiles(query).toString()
    }

    @JavascriptInterface
    fun openSystemSettings(settingType: String): String {
        return intentExecutor.openSystemSettings(settingType).toString()
    }

    @JavascriptInterface
    fun performAccessibilityAction(instruction: String, targetText: String, confirmed: Boolean): String {
        val service = BondhuAccessibilityService.instance
            ?: return JSONObject().apply {
                put("ok", false)
                put("errorCode", "ACCESSIBILITY_SERVICE_DISABLED")
                put("message", "Bondhu Accessibility Service সেটিংস থেকে চালু করা নেই।")
            }.toString()
        return service.executeUiAction(instruction, targetText, confirmed).toString()
    }

    @JavascriptInterface
    fun setBackgroundWakeWordEnabled(enabled: Boolean, wakeWord: String): String {
        if (enabled && !permissionManager.hasMicPermission()) {
            return JSONObject().apply {
                put("ok", false)
                put("errorCode", "MIC_PERMISSION_REQUIRED")
                put("message", "Background Wake Word চালু করতে Microphone অনুমতি প্রয়োজন।")
            }.toString()
        }
        val intent = Intent(activity, BondhuForegroundVoiceService::class.java).apply {
            action = if (enabled) BondhuForegroundVoiceService.ACTION_START else BondhuForegroundVoiceService.ACTION_STOP
            putExtra(BondhuForegroundVoiceService.EXTRA_WAKE_WORD, wakeWord)
        }
        activity.runOnUiThread {
            if (enabled) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    activity.startForegroundService(intent)
                } else {
                    activity.startService(intent)
                }
            } else {
                activity.startService(intent)
            }
        }
        return JSONObject().apply {
            put("ok", true)
            put("message", if (enabled) "Background Wake Word চালু হয়েছে।" else "Background Wake Word বন্ধ করা হয়েছে।")
        }.toString()
    }
}
