package com.bondhu.ai.nativebridge

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

class BondhuPermissionManager(private val activity: Activity) {

    companion object {
        const val REQ_CODE_RUNTIME = 9101
    }

    fun hasPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(activity, permission) == PackageManager.PERMISSION_GRANTED
    }

    fun hasMicPermission(): Boolean = hasPermission(Manifest.permission.RECORD_AUDIO)
    fun hasCameraPermission(): Boolean = hasPermission(Manifest.permission.CAMERA)
    fun hasCallPermission(): Boolean = hasPermission(Manifest.permission.CALL_PHONE)
    fun hasSmsPermission(): Boolean = hasPermission(Manifest.permission.SEND_SMS)
    fun hasContactsPermission(): Boolean = hasPermission(Manifest.permission.READ_CONTACTS)

    fun hasNotificationAccess(): Boolean {
        val enabledPackages = NotificationManagerCompat.getEnabledListenerPackages(activity)
        return enabledPackages.contains(activity.packageName)
    }

    fun isAccessibilityEnabled(): Boolean {
        val expectedComponent = "${activity.packageName}/${BondhuAccessibilityService::class.java.name}"
        val enabledServices = Settings.Secure.getString(
            activity.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.split(':').any { it.equals(expectedComponent, ignoreCase = true) }
    }

    fun isIgnoringBatteryOptimizations(): Boolean {
        val pm = activity.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(activity.packageName)
    }

    fun requestCoreVoicePermissions() {
        val missing = mutableListOf<String>()
        if (!hasMicPermission()) missing.add(Manifest.permission.RECORD_AUDIO)
        if (!hasCameraPermission()) missing.add(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !hasPermission(Manifest.permission.POST_NOTIFICATIONS)
        ) {
            missing.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (missing.isNotEmpty()) {
            activity.runOnUiThread {
                ActivityCompat.requestPermissions(activity, missing.toTypedArray(), REQ_CODE_RUNTIME)
            }
        }
    }

    fun requestSinglePermission(permissionKey: String): Boolean {
        val mapped = when (permissionKey.lowercase()) {
            "microphone", "mic" -> Manifest.permission.RECORD_AUDIO
            "camera" -> Manifest.permission.CAMERA
            "call", "phone" -> Manifest.permission.CALL_PHONE
            "sms" -> Manifest.permission.SEND_SMS
            "contacts" -> Manifest.permission.READ_CONTACTS
            "accessibility" -> {
                activity.runOnUiThread {
                    activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                return isAccessibilityEnabled()
            }
            "notifications" -> {
                activity.runOnUiThread {
                    activity.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }
                return hasNotificationAccess()
            }
            "battery" -> {
                activity.runOnUiThread {
                    val intent = Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:${activity.packageName}")
                    )
                    activity.startActivity(intent)
                }
                return isIgnoringBatteryOptimizations()
            }
            else -> return false
        }
        if (hasPermission(mapped)) return true
        activity.runOnUiThread {
            ActivityCompat.requestPermissions(activity, arrayOf(mapped), REQ_CODE_RUNTIME)
        }
        return false
    }
}
