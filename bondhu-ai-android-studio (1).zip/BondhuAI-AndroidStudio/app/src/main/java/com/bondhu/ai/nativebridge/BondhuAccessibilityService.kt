package com.bondhu.ai.nativebridge

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject

class BondhuAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: BondhuAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Event-driven screen updates only when service is explicitly enabled by user
    }

    override fun onInterrupt() {
        // Required lifecycle hook
    }

    fun executeUiAction(instruction: String, targetText: String, confirmed: Boolean): JSONObject {
        if (!confirmed) {
            return JSONObject().apply {
                put("ok", false)
                put("errorCode", "CONFIRMATION_REQUIRED")
                put("message", "Accessibility অ্যাকশনের আগে ব্যবহারকারীর অনুমতি প্রয়োজন।")
            }
        }
        val root = rootInActiveWindow ?: return JSONObject().apply {
            put("ok", false)
            put("errorCode", "NO_ACTIVE_WINDOW")
            put("message", "বর্তমান স্ক্রিনের তথ্য পড়া যায়নি।")
        }

        val lowerInstr = instruction.lowercase()

        val matches = root.findAccessibilityNodeInfosByText(targetText)
        if (!matches.isNullOrEmpty()) {
            for (node in matches) {
                if (node.isPassword) {
                    return JSONObject().apply {
                        put("ok", false)
                        put("errorCode", "PASSWORD_FIELD_PROTECTED")
                        put("message", "নিরাপত্তার কারণে পাসওয়ার্ড বা গোপন ইনপুট ফিল্ড অ্যাক্সেস করা নিষিদ্ধ।")
                    }
                }
                if (lowerInstr.contains("type") || lowerInstr.contains("write") || lowerInstr.contains("লিখ")) {
                    val args = Bundle().apply {
                        putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, instruction)
                    }
                    val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                    if (ok) {
                        return JSONObject().apply {
                            put("ok", true)
                            put("message", "\"$targetText\"-এ টেক্সট লেখা হয়েছে।")
                        }
                    }
                } else {
                    var targetNode: AccessibilityNodeInfo? = node
                    while (targetNode != null && !targetNode.isClickable) {
                        targetNode = targetNode.parent
                    }
                    if (targetNode != null && targetNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        return JSONObject().apply {
                            put("ok", true)
                            put("message", "\"$targetText\" বোতামে ক্লিক করা হয়েছে।")
                        }
                    }
                }
            }
        }

        if (lowerInstr.contains("scroll") || lowerInstr.contains("নিচে") || lowerInstr.contains("উপরে")) {
            val action = if (lowerInstr.contains("up") || lowerInstr.contains("উপরে")) {
                AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            } else {
                AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            }
            val scrollable = findScrollableNode(root)
            if (scrollable != null && scrollable.performAction(action)) {
                return JSONObject().apply {
                    put("ok", true)
                    put("message", "স্ক্রিন স্ক্রল করা হয়েছে।")
                }
            }
        }

        val labels = JSONArray()
        collectSafeTextNodes(root, labels, 20)
        return JSONObject().apply {
            put("ok", false)
            put("errorCode", "UI_TARGET_NOT_FOUND")
            put("message", "স্ক্রিনে \"$targetText\" খুঁজে পাওয়া যায়নি।")
            put("details", JSONObject().put("visibleLabels", labels))
        }
    }

    private fun findScrollableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val found = findScrollableNode(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    private fun collectSafeTextNodes(node: AccessibilityNodeInfo?, out: JSONArray, limit: Int) {
        if (node == null || out.length() >= limit) return
        if (!node.isPassword) {
            val txt = node.text?.toString()?.trim()
            if (!txt.isNullOrEmpty() && !Regex("\\b\\d{4,8}\\b").containsMatchIn(txt)) {
                out.put(txt)
            }
        }
        for (i in 0 until node.childCount) {
            collectSafeTextNodes(node.getChild(i), out, limit)
        }
    }
}
