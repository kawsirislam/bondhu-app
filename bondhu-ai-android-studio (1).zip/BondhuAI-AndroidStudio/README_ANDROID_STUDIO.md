# Bondhu AI - Android Studio Project

এই প্রজেক্টটি **Bondhu AI**-এর সম্পূর্ণ ওয়েব ফিচার + **Android Native Kotlin Bridge (`window.BondhuAndroidBridge`)** সহ Android Studio-তে সরাসরি Build ও APK তৈরি করার জন্য প্রস্তুত করা হয়েছে।

## ভেতরে কী কী আছে

1. **`MainActivity.kt`**:
   - ফুল-স্ক্রিন WebView যাতে Bondhu AI-এর সব ফিচার (Chat, Bondhu ID Login, Live Voice, Image Generation/Editing, Notifications) চলে।
   - `windowSoftInputMode="adjustResize"` + WindowInsets IME হ্যান্ডলিং যাতে কীবোর্ড খুললে Chat Input Box সুন্দরভাবে উপরে উঠে আসে।
   - WebRTC মাইক্রোফোন ও ক্যামেরা পারমিশন অটো-ব্রিজিং, ফাইল/ক্যামেরা আপলোড (`FileProvider`) এবং কুকি/সেশন পারসিস্টেন্স।
   - `webView.addJavascriptInterface(BondhuWebViewBridge(this), "BondhuAndroidBridge")` সরাসরি যুক্ত।
2. **Native Bridge Kotlin Modules (`com.bondhu.ai.nativebridge`)**:
   - `BondhuWebViewBridge.kt`: Web App ও Android OS-এর মূল ব্রিজ।
   - `BondhuIntentExecutor.kt`: Facebook, Facebook Lite, TikTok, YouTube, WhatsApp, Messenger, Telegram, Instagram, bKash, Chrome সহ ইনস্টল করা যেকোনো অ্যাপ খোঁজা ও খোলা, কল, SMS, ক্যামেরা, সেটিংস ও ফাইল খোঁজা।
   - `BondhuPermissionManager.kt`: Runtime পারমিশন (`RECORD_AUDIO`, `CAMERA`, `CALL_PHONE`, `SEND_SMS`, `READ_CONTACTS`, `POST_NOTIFICATIONS`) এবং Accessibility/Notification/Battery সেটিংস।
   - `BondhuAccessibilityService.kt`: ব্যবহারকারীর অনুমতি সাপেক্ষে স্ক্রিন রিডিং/ক্লিক/স্ক্রল (পাসওয়ার্ড ফিল্ড সুরক্ষিত)।
   - `BondhuNotificationListenerService.kt`: অনুমতি সাপেক্ষে নোটিফিকেশন পড়া (OTP/Password/CVV স্বয়ংক্রিয়ভাবে গোপন রাখে)।
   - `BondhuForegroundVoiceService.kt`: Wake Word ("বন্ধু") ফোরগ্রাউন্ড ভয়েস সার্ভিস ও `WAKE_WORD_DETECTED` ব্রডকাস্ট।

## Android Studio-তে Build করার ধাপ

1. এই ZIP ফাইলটি Extract করুন।
2. **Android Studio** খুলুন -> **Open** ক্লিক করে `BondhuAI` (যে ফোল্ডারে `settings.gradle.kts` আছে) সিলেক্ট করুন।
3. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন (Android Studio প্রথমবার Gradle Wrapper ডাউনলোড করবে)।
4. প্রয়োজন হলে `app/src/main/res/values/strings.xml`-এ `bondhu_server_url` আপনার প্রকাশিত সার্ভার URL অনুযায়ী আপডেট করুন (অ্যাপের ভেতর থেকেও Server URL পরিবর্তন করা যায়)।
5. মেনু থেকে **Build -> Build Bundle(s) / APK(s) -> Build APK(s)** ক্লিক করে APK তৈরি করুন এবং আপনার Android ফোনে ইনস্টল করুন।
6. ফোনে অ্যাপ চালু করে সেটিংস থেকে **Accessibility (Bondhu AI)** ও **Notification Access** চালু করলে Voice-এর মাধ্যমে Facebook, TikTok, কল ও অন্যান্য অ্যাকশন সরাসরি কাজ করবে।
